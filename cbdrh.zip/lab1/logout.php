<?php
include_once 'user.php';
user::logout();
?>