<div class="d-flex flex-column flex-md-row align-items-center p-3 px-md-4 mb-3 bg-dark border-bottom box-shadow">
  <h4 class="my-0 mr-md-auto font-weight-normal text-white"><a class="p-2 text-white home title" href="/cars">{{config('app.name')}}</a></h4>
    <nav class="my-2 my-md-0 mr-md-3">
      <a class="p-2 text-white title" href="/car/new">ADD CAR</a>
      <a class="p-2 text-white title" href="/reviews">REVIEWS</a>
    </nav>
  </div>