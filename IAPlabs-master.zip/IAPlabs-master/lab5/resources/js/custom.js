$(document).ready(function() {
    $('#cars').DataTable();

    $(function () {
        $("#studentnumber").children().remove("optgroup");
        console.log("I am a datatable");
    });
    
} );
