# IAPlabs
My labs have been refactored into 4 files - lab 1, lab 5, the external app and the api file

# lab1
Consists of all labs before the laravel exercise

# external app
Consists of the ordering feature

# api
The api implementation of the ordering feature lives here

# lab5 
Consists of the laravel exercise
To run this lab successfully excute the following commands


***Composer install***
- to install all dependencies

***php artisan migrate*** 
- to run all migrations - the database name is homestead, the user is root

***If you experience a server 500 error execute the following steps***
- Rename the .env.example file to .env 
- then run the following command

***php artisan key:generate***
